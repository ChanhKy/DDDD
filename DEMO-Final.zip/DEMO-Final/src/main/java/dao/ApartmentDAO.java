package dao;

import entities.Apartment;

public interface ApartmentDAO {
void save(Apartment apartment);
}
