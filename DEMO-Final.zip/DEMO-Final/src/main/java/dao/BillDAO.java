package dao;

import entities.Bill;

public interface BillDAO {
	void save(Bill bill);
}
