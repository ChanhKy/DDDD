package dao;

import entities.Customer;

public interface CustomerDAO {
void save(Customer customer);
}
