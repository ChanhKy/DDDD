package dao;

import entities.Employee;

public interface EmployeeDAO {
 void save(Employee employee);
}
