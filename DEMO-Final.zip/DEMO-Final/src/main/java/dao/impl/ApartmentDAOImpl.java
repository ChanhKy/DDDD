package dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;

import dao.ApartmentDAO;
import entities.Apartment;
import utils.HibernateUtils;

public class ApartmentDAOImpl implements ApartmentDAO {

	@Override
	public void save(Apartment apartment) {
		Session session = null;
		try {
			session = HibernateUtils.getSessionFactory().openSession();
			session.beginTransaction();
			session.save(apartment);
			session.getTransaction().commit();
			System.out.println("THEM MOI APARTMENT THANH CONG");
		} catch (RuntimeException e) {
			e.printStackTrace();
		} finally {
		}
		if (session != null) {
			session.close();
		}

	}

	@SuppressWarnings("unchecked")
	public List<Apartment> getApartmentByNumberRoomAndStatus(int number, String status) {
		Session session = null;
		List<Apartment> apartments = null;
		try {
			session = HibernateUtils.getSessionFactory().openSession();
			session.beginTransaction();

			String hql = "FROM Apartment WHERE apartmentRoom =:number AND apartmentStatus =:status";

			apartments = session.createQuery(hql).setParameter("number", number).setParameter("status", status).list();
			session.getTransaction().commit();

		} catch (RuntimeException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return apartments;
	}

	@SuppressWarnings("unchecked")
	public List<Apartment> getApartmentByID(int id) {
		Session session = null;
		List<Apartment> apartments = null;
		try {
			session = HibernateUtils.getSessionFactory().openSession();
			session.beginTransaction();

			String hql = "FROM Apartment WHERE apartmentId =:id";

			apartments = session.createQuery(hql).setParameter("id", id).list();
			session.getTransaction().commit();

		} catch (RuntimeException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return apartments;
	}

	public List<Object[]> getAllApartmentHasBuy() {
		Session session = null;
		List<Object[]> objects = null;

		try {
			session = HibernateUtils.getSessionFactory().openSession();
			session.beginTransaction();

			String hql = "FROM Apartment a INNER JOIN a.bills b ";

			objects = session.createQuery(hql).list();
			session.getTransaction().commit();

		} catch (RuntimeException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return objects;
	}
	
	public List<Object[]> getAllApartmentDaBanCoKhachHangOHue() {
		Session session = null;
		List<Object[]> objects = null;

		try {
			session = HibernateUtils.getSessionFactory().openSession();
			session.beginTransaction();

			String hql = "FROM Apartment a INNER JOIN a.bills b JOIN b.customer c where c.customerAddress = 'Hue' ";

			objects = session.createQuery(hql).list();
			session.getTransaction().commit();

		} catch (RuntimeException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return objects;
	}
	

	public void updateStatusByString(int id) {
		Session session = null;
		try {
			session = HibernateUtils.getSessionFactory().openSession();
			session.beginTransaction();

			String hql = "UPDATE Apartment SET apartmentStatus = 'Da Ban' WHERE apartmentId =:id";
			session.createQuery(hql).setParameter("id", id).executeUpdate();
			session.getTransaction().commit();
			System.out.println("DA UPDATE THANH CONG");
		} catch (RuntimeException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	public boolean deleteApartmentByApartmentCode(String apartmentCode ) {
		Session session = null;
		
		try {
			session = HibernateUtils.getSessionFactory().openSession();
			session.beginTransaction();
			
			Query query = session.createQuery("delete Apartment where apartmentCode =:code");
			query.setParameter("code", apartmentCode);
			int result = query.executeUpdate();
			session.getTransaction().commit();
			System.out.println("DELETE THANH CONG");
			return true;
		}catch(RuntimeException e) {
			e.printStackTrace();
		}finally {
			if (session != null) {
				session.close();
			}
		}
		return false;
	}

}
