package dao.impl;

import java.util.List;

import org.hibernate.Session;

import dao.BillDAO;
import entities.Bill;
import utils.HibernateUtils;

public class BillDAOImpl implements BillDAO {

	@Override
	public void save(Bill bill) {
		Session session = null;
		try {
			session = HibernateUtils.getSessionFactory().openSession();
			session.beginTransaction();
			session.save(bill);
			session.getTransaction().commit();
			System.out.println("SAVE BILL THANH CONG");
		} catch (RuntimeException e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}
	
	@SuppressWarnings("unchecked")
	public List<Bill>  getBill(int apartID) {
	List<Bill> bills = null;
		Session session = null;
		try {
			session =HibernateUtils.getSessionFactory().openSession();
			session.beginTransaction();
			
			String hql = "FROM Bill WHERE apartment.apartmentId =:apartID";
			bills = session.createQuery(hql).setParameter("apartID", apartID).list();
			
			session.getTransaction().commit();
		}catch(RuntimeException e) {
			e.printStackTrace();
		}
		return bills;
	}

	@SuppressWarnings("unchecked")
	public List<Bill> getBillcheckEmploye(int id) {
		List<Bill> bills = null;
		Session session = null;
		try {
			session = HibernateUtils.getSessionFactory().openSession();
			session.beginTransaction();
			
			String sql = "Select * from Bill where Employee_ID =:id";
			bills = session.createNativeQuery(sql).addEntity(Bill.class).setParameter("id", id).list();
		}catch(RuntimeException e) {
			e.printStackTrace();
		}finally {
			if (session != null ) {
				session.close();
			}
		}
		return bills;
	}

}
