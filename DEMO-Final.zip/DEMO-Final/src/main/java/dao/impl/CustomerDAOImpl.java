package dao.impl;

import org.hibernate.Session;

import dao.CustomerDAO;
import entities.Customer;
import utils.HibernateUtils;

public class CustomerDAOImpl implements CustomerDAO {

	@Override
	public void save(Customer customer) {
		Session session = null;
		try {
			session = HibernateUtils.getSessionFactory().openSession();
			session.beginTransaction();
			session.save(customer);
			session.getTransaction().commit();
			System.out.println("THEM MOI CUSTOMER THANH CONG");
		}catch(RuntimeException e) {
			e.printStackTrace();
		}finally {
			if (session != null) {
				session.close();
			}
		}
		
	}

}
