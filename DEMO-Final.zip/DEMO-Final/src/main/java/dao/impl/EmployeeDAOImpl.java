package dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;

import dao.EmployeeDAO;
import entities.Employee;
import utils.HibernateUtils;

public class EmployeeDAOImpl implements EmployeeDAO{

	public void save(Employee employee) {
		Session session = null;
		try {
			session = HibernateUtils.getSessionFactory().openSession();
			session.beginTransaction();
			session.save(employee);
			session.getTransaction().commit();
			System.out.println("THEM MOI EMPLOYEE THANH CONG");
		}catch(RuntimeException e) {
			e.printStackTrace();
		}finally {
			if (session != null)  {
				session.close();
			}
		}
		
	}
	
	@SuppressWarnings("unchecked")
	public List<Object []> findAllEmployeeAndBill() {
		List<Object []> employees  =null;
		Session session = null;
		try {
			session = HibernateUtils.getSessionFactory().openSession();
			session.beginTransaction();
			
			String sql = "SELECT distinct e.* , b.* FROM Employee e JOIN Bill b ON e.Employee_ID = b.Employee_ID";
			@SuppressWarnings("rawtypes")
			Query query = session.createNativeQuery(sql).addEntity("e", Employee.class).addJoin("b", "e.bills");
			
			employees = query.list();
			session.getTransaction().commit();
			
		}catch(RuntimeException e) {
			e.printStackTrace();
		}finally {
			if (session != null) {
				session.close();
			}
		}
		return employees;
	}

}
