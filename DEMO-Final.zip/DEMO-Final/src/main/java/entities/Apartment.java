package entities;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table
public class Apartment {

	@Id
	@Column(name = "Apartment_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int apartmentId;

	@Column(name = "Apartment_Code")
	private String apartmentCode;

	@Column(name = "Apartment_Room")
	private int apartmentRoom;

	@Column(name = "Apartment_Door")
	private String apartmentDoor;

	@Column(name = "Apartment_Price")
	private int apartmentPrice;

	@Column(name = "Apartment_Status")
	private String apartmentStatus;

	@OneToMany(mappedBy = "apartment", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private Set<Bill> bills;

	public Apartment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Apartment(int apartmentId) {
		super();
		this.apartmentId = apartmentId;
	}

	public Apartment(String apartmentCode, int apartmentRoom, String apartmentDoor, int apartmentPrice,
			String apartmentStatus) {
		super();
		this.apartmentCode = apartmentCode;
		this.apartmentRoom = apartmentRoom;
		this.apartmentDoor = apartmentDoor;
		this.apartmentPrice = apartmentPrice;
		this.apartmentStatus = apartmentStatus;
	}

	public int getApartmentId() {
		return apartmentId;
	}

	public void setApartmentId(int apartmentId) {
		this.apartmentId = apartmentId;
	}

	public String getApartmentCode() {
		return apartmentCode;
	}

	public void setApartmentCode(String apartmentCode) {
		this.apartmentCode = apartmentCode;
	}

	public int getApartmentRoom() {
		return apartmentRoom;
	}

	public void setApartmentRoom(int apartmentRoom) {
		this.apartmentRoom = apartmentRoom;
	}

	public String getApartmentDoor() {
		return apartmentDoor;
	}

	public void setApartmentDoor(String apartmentDoor) {
		this.apartmentDoor = apartmentDoor;
	}

	public int getApartmentPrice() {
		return apartmentPrice;
	}

	public void setApartmentPrice(int apartmentPrice) {
		this.apartmentPrice = apartmentPrice;
	}

	public String getApartmentStatus() {
		return apartmentStatus;
	}

	public void setApartmentStatus(String apartmentStatus) {
		this.apartmentStatus = apartmentStatus;
	}

	public Set<Bill> getBills() {
		return bills;
	}

	public void setBills(Set<Bill> bills) {
		this.bills = bills;
	}

	@Override
	public String toString() {
		return "Apartment [" + apartmentId + "\t" + apartmentCode +"\t"
				+ apartmentRoom + "\t" + apartmentDoor + "\t" + apartmentPrice
				+ "\t" + apartmentStatus +"\t" ;
	}

}
