 package entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table
public class Bill {

	@Id
	@Column(name = "Bill_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int billId;

	@ManyToOne
	@JoinColumn(name = "Employee_ID", referencedColumnName = "Employee_ID")
	private Employee employee;

	@ManyToOne
	@JoinColumn(name = "Apartment_ID", referencedColumnName = "Apartment_ID")
	private Apartment apartment;

	@ManyToOne
	@JoinColumn(name = "Customer_ID", referencedColumnName = "Customer_ID")
	private Customer customer;

	@Column(name = "Bill_Date")
	@Temporal(TemporalType.DATE)
	private Date billDate;

	@Column(name = "Bill_Price")
	private int billPrice;

	public Bill() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Bill(Employee employee, Apartment apartment, Customer customer, Date billDate, int billPrice) {
		super();
		this.employee = employee;
		this.apartment = apartment;
		this.customer = customer;
		this.billDate = billDate;
		this.billPrice = billPrice;
	}

	public int getBillId() {
		return billId;
	}

	public void setBillId(int billId) {
		this.billId = billId;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Apartment getApartment() {
		return apartment;
	}

	public void setApartment(Apartment apartment) {
		this.apartment = apartment;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Date getBillDate() {
		return billDate;
	}

	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}

	public int getBillPrice() {
		return billPrice;
	}

	public void setBillPrice(int billPrice) {
		this.billPrice = billPrice;
	}

	@Override
	public String toString() {
		return "Bill [" + billId + "\t" + employee + "\t" + apartment + "\t" + customer + "\t" + billDate + "\t"
				+ billPrice + "]";
	}

}
