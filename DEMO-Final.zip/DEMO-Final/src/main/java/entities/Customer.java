package entities;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table
public class Customer {

	@Id
	@Column(name = "Customer_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int customerId;
	
	@Column(name = "Customer_Name")
	private String customerName;
	
	@Column(name = "Customer_So_DT")
	private int customerSoDT;
	
	@Column(name = "Customer_DOB")
	@Temporal(TemporalType.DATE)
	private Date customerDob;
	
	@Column(name = "Customer_Address")
	private String customerAddress;
	
	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
	private Set<Bill> bills;

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(int customerId) {
		super();
		this.customerId = customerId;
	}

	public Customer(String customerName, int customerSoDT, Date customerDob, String customerAddress) {
		super();
		this.customerName = customerName;
		this.customerSoDT = customerSoDT;
		this.customerDob = customerDob;
		this.customerAddress = customerAddress;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getCustomerSoDT() {
		return customerSoDT;
	}

	public void setCustomerSoDT(int customerSoDT) {
		this.customerSoDT = customerSoDT;
	}

	public Date getCustomerDob() {
		return customerDob;
	}

	public void setCustomerDob(Date customerDob) {
		this.customerDob = customerDob;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public Set<Bill> getBills() {
		return bills;
	}

	public void setBills(Set<Bill> bills) {
		this.bills = bills;
	}

	@Override
	public String toString() {
		return "Customer [" + customerId + "\t" + customerName + "\t"
				+ customerSoDT + "\t" + customerDob + "\t" + customerAddress + "\t"
				 + "]";
	}
	
	
}
