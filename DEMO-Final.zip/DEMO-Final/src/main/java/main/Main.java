package main;

import java.util.Scanner;

import services.ApartmentServices;
import services.BillServices;
import services.CustomerServices;
import services.EmployeeServices;

public class Main {

	public static void main(String[] args) {
		EmployeeServices employeeServices = new EmployeeServices();
		CustomerServices customerServices = new CustomerServices();
		ApartmentServices apartmentServices = new ApartmentServices();
		BillServices billServices = new BillServices();
		Scanner sc = new Scanner(System.in);
		boolean check = true;
		String input;

		do {
			System.out.println("1. save Employee");
			System.out.println("2. save Cusomer");
			System.out.println("3. save Apartment");
			System.out.println("4. save Bill");
			System.out.println("5. Find Apartment By BedRoom number and Status");
			System.out.println("6. checkNumberBillOfEmployee");
			System.out.println("0. EXIT");

			input = sc.nextLine();
			switch (input) {
			case "1":
				employeeServices.save();
				break;
			case "2":
				customerServices.save();
				break;
			case "3":
				apartmentServices.save();
				break;
			case "4":
				billServices.save();
				break;
			case "5":
				apartmentServices.getApartmentByNumberRoomAndStatus();
				break;
			case "6":
				billServices.checkNumberBillOfEmployee();
				break;
			case "0":
				check = false;
				break;
			default:
				break;
			}
		} while (check);

	}
}
