package services;

import java.util.List;
import java.util.Scanner;

import dao.impl.ApartmentDAOImpl;
import dao.impl.BillDAOImpl;
import entities.Apartment;
import entities.Bill;
import entities.Customer;

public class ApartmentServices {
	public static void main(String[] args) {
//		new ApartmentServices().equalStatusApartment(); 
//		new ApartmentServices().thaydoitrangthai();
//		new ApartmentServices().showAllApartmentDaBan();
//		new ApartmentServices().getAllApartmentDaBanCoKhachHangOHue();
		new ApartmentServices().deleteApartment();
	}

	ApartmentDAOImpl apartmentDAO = new ApartmentDAOImpl();
	BillDAOImpl billDAO = new BillDAOImpl();
	Scanner sc = new Scanner(System.in);
	public void save() {
		System.out.println("Them moi Apartment ");
		System.out.print("Enter Apartment Code: ");
		String  aprtCode = sc.nextLine();
		System.out.print("Enter Number bedroom: ");
		int bedRoom = Integer.valueOf(sc.nextLine());
		System.out.print("Enter Door direction: ");
		String door = sc.nextLine();
		System.out.print("Enter Price: ");
		int price = Integer.valueOf(sc.nextLine());
		System.out.print("Enter Status");
		String status = sc.nextLine();
		
		Apartment ap = new Apartment(aprtCode, bedRoom, door, price, status);
		apartmentDAO.save(ap);
	}
	
	
	
	
	public void getApartmentByNumberRoomAndStatus() {
		System.out.print("Enter bed Room number: ");
		int number = Integer.valueOf(sc.nextLine());
		System.out.print("Enter Status: ");
		String status = sc.nextLine();
		
		List<Apartment> apartments =  apartmentDAO.getApartmentByNumberRoomAndStatus(number, status);
		for (Apartment apartment : apartments) {
			System.out.println(apartment);
		}
		
	}
	
	public void showAllApartmentDaBan() {
		List<Object[]> objects = apartmentDAO.getAllApartmentHasBuy();
		for (Object[] ob : objects) {
//			System.out.println((Apartment)ob[0]);
			System.out.println((Bill) ob[1]);
		}
	}
	
	public void getAllApartmentDaBanCoKhachHangOHue() {
		List<Object[]> objects = apartmentDAO.getAllApartmentDaBanCoKhachHangOHue();
		for (Object[] ob : objects) {
//			System.out.println((Apartment)ob[0]);
//			System.out.println((Bill) ob[1]);
			System.out.println((Customer) ob[2]);
		

		}
	}
	
	
	
	
	
	public void equalStatusApartment() {
		System.out.println("Enter Apartment can kiem tra: ");
		int  id = Integer.valueOf(sc.nextLine());
		
		List<Apartment> apartments = apartmentDAO.getApartmentByID(id);
		List<Bill> bills = billDAO.getBill(id);
		
		if (apartments.size() == bills.size() ) {
			apartmentDAO.updateStatusByString(id);
		}else {
			System.out.println("Id khong trung nhau");
		}
	}
	
	
	
	
	
	public void thaydoitrangthai() {
		System.out.print("Enter id can thay doi:  " );
		int  id = Integer.valueOf(sc.nextLine());
		apartmentDAO.updateStatusByString(id);
	}
	
	public void deleteApartment() {
		System.out.print("Nhap ApartmentCode can xoa: ");
		String code = sc.nextLine();
		apartmentDAO.deleteApartmentByApartmentCode(code);
	}
}
