package services;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import dao.impl.BillDAOImpl;
import entities.Apartment;
import entities.Bill;
import entities.Customer;
import entities.Employee;

public class BillServices {

	BillDAOImpl billDAO = new BillDAOImpl();
	Scanner sc = new Scanner(System.in);

	@SuppressWarnings("deprecation")
	public void save() {
		System.out.println("Them moi Bill");
		System.out.print("Enter Employee_ID: ");
		Employee emID = new Employee(Integer.valueOf(sc.nextLine()));
		System.out.print("Enter Apartment_ID: ");
		Apartment apID = new Apartment(Integer.valueOf(sc.nextLine()));
		System.out.print("Enter Customer_ID: ");
		Customer cuID = new Customer(Integer.valueOf(sc.nextLine()));
		System.out.print("Enter Buy_Date: ");
		Date date = new Date(sc.nextLine());
		System.out.print("Enter Price: ");
		int price = Integer.valueOf(sc.nextLine());

		Bill bill = new Bill(emID, apID, cuID, date, price);
		billDAO.save(bill);
	}

	public void checkNumberBillOfEmployee() {
		List<Bill> bills;

		System.out.print("Enter Employee ID: ");
		int id = Integer.valueOf(sc.nextLine());
		bills = billDAO.getBillcheckEmploye(id);
		if (bills.size() >= 3) {
			System.out.println("Nhan vien da ban qua so can ho cho phep");
		}else {
			System.out.println("Tiep tuc ban di");
		}

	}
}
