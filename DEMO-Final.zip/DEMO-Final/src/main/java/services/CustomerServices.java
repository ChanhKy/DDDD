package services;

import java.util.Date;
import java.util.Scanner;

import dao.impl.CustomerDAOImpl;
import entities.Customer;

public class CustomerServices {

	CustomerDAOImpl customerDAO = new CustomerDAOImpl();
	Scanner sc = new Scanner(System.in);
	
	@SuppressWarnings("deprecation")
	public void save() {
		System.out.println("Them moi Customer: ");
		System.out.print("Enter Customer name: ");
		String name = sc.nextLine();
		System.out.print("Enter phone number: ");
		int phone = Integer.valueOf(sc.nextLine());
		System.out.print("Enter DOB: ");
		Date date = new Date(sc.nextLine());
		System.out.print("Enter Customer Address: ");
		String address = sc.nextLine();
		Customer cus = new Customer(name, phone, date, address);
		customerDAO.save(cus);
	}
}
