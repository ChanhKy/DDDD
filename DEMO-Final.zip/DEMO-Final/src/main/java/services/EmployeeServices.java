package services;

import java.util.List;
import java.util.Scanner;

import dao.impl.EmployeeDAOImpl;
import entities.Bill;
import entities.Employee;

public class EmployeeServices {
	public static void main(String[] args) {
		new EmployeeServices().showListEmployeeAndBill();
	}

	EmployeeDAOImpl employeeDAO = new EmployeeDAOImpl();
	Scanner sc = new Scanner(System.in);

	public void save() {
		System.out.println("THEM MOI EMPLOYEE");
		System.out.print("Enter Employee name: ");
		String name = sc.nextLine();
		System.out.print("Enter role: ");
		String roleS = sc.nextLine();
		Employee e1 = new Employee(name, roleS);
		employeeDAO.save(e1);
	}

	public void showListEmployeeAndBill() {
		List<Object[]> empList = employeeDAO.findAllEmployeeAndBill();
		for (Object[] object : empList) {

			Employee em1 = (Employee) object[0];
			System.out.println(em1);

			for (Bill bill : em1.getBills()) {
				System.out.println(bill);
			}
		}
	}
}
